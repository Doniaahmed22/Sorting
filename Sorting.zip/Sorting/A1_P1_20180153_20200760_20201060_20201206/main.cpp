///problem 1
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include <string>
using namespace std;
class BigInt
{
    string Decstr;
public:
    BigInt(string decstr="\0")
    {
        Decstr=decstr;
        if(Decstr != "\0")
        {
            for(int i=0; i<this->size(); i++)
            {
                if(!check_if_num(Decstr[i]))
                {
                    cout<<"input bad"<<endl;
                    break;
                }
            }
        }
    }
    bool check_if_num(char c)
    {
        return((int)c>=48&&(int)c<=57);

    }
    BigInt(int decInt)
    {
        Decstr=to_string(decInt);
    }
    int size()
    {
        int length=0,i=0;
        while(this->Decstr[i] != '\0')
        {
            length++;
            i++;
        }
        return length;
    }
    BigInt operator+(BigInt obj)
    {
        BigInt newbidint;
        newbidint.Decstr=Add(*this,obj);
        return newbidint;
    }
    string Add(BigInt&obj1,BigInt&obj2)
    {
        int carry=0,num1,num2,sum;
        string newstring="\0",s1="\0",s2="\0";
        num1=obj1.size();
        num2=obj2.size();
        while(num1!=0&&num2!=0)
        {
            s1="\0",s2="\0";
            s1+=obj1.Decstr[--num1];
            s2+=obj2.Decstr[--num2];
            sum=0;
            sum=stoi(s1)+stoi(s2)+carry;
            if(carry == 1)
                carry--;
            if(sum >= 10)
            {
                carry++;
                sum %= 10;
            }
            newstring=(to_string(sum))+newstring;
        }
        while(num1!=0)
        {
            newstring=obj1.Decstr[--num1]+newstring;
        }
        while(num2!=0)
        {
            newstring=obj2.Decstr[--num2]+newstring;
        }
        return newstring;
    }
    BigInt operator-(BigInt obj)
    {
        BigInt new_bigint;
        new_bigint.Decstr=substract(*this,obj);
        return new_bigint;
    }
    string substract(BigInt&obj1,BigInt&obj2)
    {
        int i=0,num1,num2;
        string newstring="\0",s1="\0",s2="\0";
        bool Nagative_number=false;
        num1=obj1.size();
        num2=obj2.size();
        if(num1 < num2)
        {
            Nagative_number=true;
        }
        while(num1 == num2)
        {
            if( int(obj1.Decstr[i]) < int(obj2.Decstr[i]))
            {
                Nagative_number=true;
                break;
            }
            else if(i == num1)
                break;
            else
                i++;
        }
        while(num1!=0 && num2!=0)
        {
            s1="\0",s2="\0";
            s1+=obj1.Decstr[--num1];
            s2+=obj2.Decstr[--num2];
            newstring=(to_string(abs(stoi(s1)-stoi(s2))))+newstring;
        }
        while(num1!=0)
        {
            newstring=obj1.Decstr[--num1]+newstring;
        }
        while(num2!=0)
        {
            newstring=obj2.Decstr[--num2]+newstring;
        }
        if(Nagative_number == true)
            newstring="- "+newstring;
        return newstring;
    }
    BigInt operator=(BigInt obj)
    {
        BigInt newbigint;
        newbigint.Decstr=obj.Decstr;
        return newbigint;
    }
    friend ostream&operator<<(ostream& out, BigInt&b)
    {
        out<<b.Decstr;
        return out;
    }
};
int main()
{
    BigInt num1("123456789012345678901234567890");
    BigInt num2("113456789011345678901134567890");
    BigInt num3 = num2 + num1;
    cout << "num1 = " << num1 << endl;
    cout << "num2 = " << num2 << endl;
    //236913578023691357802369135780
    cout << "num2 + num1 = " << num3 << endl;
}
