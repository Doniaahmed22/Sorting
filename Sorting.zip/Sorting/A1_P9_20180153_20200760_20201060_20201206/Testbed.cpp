// Created by AbdOo on 4/27/2022.
//

#include "Testbed.h"

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using std::cout;
using std::endl;
using std::setw;

Testbed::Testbed()
{
}

int* Testbed::GenerateRandomList(int min, int max, int size)
{
    int* array = new int[size];
    for (int i = 0; i < size; i++)
    {
        array[i] = rand() % max + min;
    }
    return array;
}

int* Testbed::GenerateReverseOrderedList(int min, int max, int size)
{
    int* array = GenerateRandomList(min, max, size);
    for (int i = 1; i < size; i++)
    {
        int insert = array[i];
        int beg = 0, end = i;
        while (beg < end)
        {
            int mid = (beg + end) / 2;
            if (insert <= array[mid])
            {
                beg = mid + 1;
            }
            else
            {
                end = mid;
            }
        }

        for (int j = i; j > end; j--)
            array[j] = array[j - 1];

        array[beg] = insert;
    }
    return array;
}

double Testbed::RunOnce(Sorter* sorter, int* data, int size)
{
    clock_t t = clock();
    sorter->Sort(data, size);
    t = clock() - t;
    return (double)(t) / CLOCKS_PER_SEC;
}

double Testbed::RunAndAverage(Sorter* sorter, int type, int min, int max, int size, int sets_num)
{
    double sum_t = 0;
    for (int i = 0; i < sets_num; i++)
    {
        int *array = type != 1 ? GenerateRandomList(min, max, size) : GenerateReverseOrderedList(min, max, size);
        sum_t += RunOnce(sorter, array, size);
        delete[] array;
    }
    return sum_t / sets_num;
}

void Testbed::RunExperiment(Sorter* sorter, int type, int min, int max, int min_val, int max_val, int sets_num, int step)
{
    cout << setw(7) << "Set Size" << setw(15) << "Average Time" << endl;
    for (int n = min_val; n <= max_val; n += step)
    {
        cout << setw(7) << n << setw(15) << RunAndAverage(sorter, type, min, max, n, sets_num) << endl;
    }
}

