#ifndef A1_P9_SELECTIONSORTER_H
#define A1_P9_SELECTIONSORTER_H
#include "Sorter.h"


class SelectionSorter : public Sorter
{
public:
    SelectionSorter();
    void Sort(int* array, int size);
};



#endif //A1_P9_SELECTIONSORTER_H
