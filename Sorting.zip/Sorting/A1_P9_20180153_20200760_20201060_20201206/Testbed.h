#ifndef A1_P9_TESTBED_H
#define A1_P9_TESTBED_H
#include "Sorter.h"
class Testbed {
public:
    Testbed();
    int* GenerateRandomList(int min, int max, int size);
    int* GenerateReverseOrderedList(int min, int max, int size);
    double RunOnce(Sorter* sorter, int* data, int size);
    double RunAndAverage(Sorter* sorter, int type, int min, int max, int size, int sets_num);
    void RunExperiment(Sorter* sorter, int type, int min, int max, int min_val, int max_val, int sets_num, int step);
};






#endif //A1_P9_TESTBED_H
