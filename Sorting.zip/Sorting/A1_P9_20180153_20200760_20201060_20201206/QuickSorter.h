//
// Created by AbdOo on 4/27/2022.
//

#ifndef A1_P9_QUICKSORTER_H
#define A1_P9_QUICKSORTER_H
#include "Sorter.h"


class QuickSorter : public Sorter {
private:
    int partition(int *array, int beg, int last);
    void Sort(int* array, int beg, int last);

public:
    QuickSorter();
    void Sort(int* array, int size);
};


#endif //A1_P9_QUICKSORTER_H
