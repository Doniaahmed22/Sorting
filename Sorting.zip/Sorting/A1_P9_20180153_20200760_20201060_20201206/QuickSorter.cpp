//
// Created by AbdOo on 4/27/2022.
//

#include "QuickSorter.h"
#include <algorithm>
using namespace std;

QuickSorter::QuickSorter() {
}

int QuickSorter::partition(int *array, int beg, int last) {
    int mid = beg + (last - beg) / 2;
    int pivot = array[mid];

    swap(array[mid], array[beg]);

    int i = beg + 1, j = last;
    while (i <= j) {
        while(i <= j && array[i] <= pivot)  { i++; }
        while(i <= j && array[j] > pivot)   { j--; }

        if (i < j) {
            swap(array[i], array[j]);
        }
    }

    swap(array[i - 1], array[beg]);
    return i - 1;
}

void QuickSorter::Sort(int* array, int beg, int last){
    if (beg >= last) {
        return;
    }
    int part = partition(array, beg, last);
    QuickSorter::Sort(array, beg, part - 1);
    QuickSorter::Sort(array, part + 1, last);
}

void QuickSorter::Sort(int* array, int size){
    QuickSorter::Sort(array, 0, size - 1);
}

