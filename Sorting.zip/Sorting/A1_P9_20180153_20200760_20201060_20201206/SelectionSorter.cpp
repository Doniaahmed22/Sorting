#include "SelectionSorter.h"
#include <algorithm>

using std::swap;

SelectionSorter::SelectionSorter() {
}

void SelectionSorter::Sort(int* array, int size){
    int min_i;
    for (int i = 0; i < size; i++) {
        min_i = i;
        for (int j = i; j < size; j++) {
            if (array[j] < array[min_i]) {
                min_i = j;
            }
        }
        swap(array[i], array[min_i]);
    }
}
