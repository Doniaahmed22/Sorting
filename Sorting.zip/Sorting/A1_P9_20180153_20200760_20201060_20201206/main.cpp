///problem 9
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include "Testbed.h"
#include "QuickSorter.h"
#include "SelectionSorter.h"

using namespace std;

void printArray(int* array, int size)
{
    for (int i = 0; i != size; i++)
    {
        cout << array[i] << ' ';
    }
    cout << endl;
}

int main()
{
    SelectionSorter s1;
    QuickSorter s2;
    cout << "Selection Sort: ";
    int arr_1[10] = {9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    s1.Sort(arr_1, 10);
    printArray(arr_1, 10);

    cout << "Quick Sort: ";
    int arr_2[10] = {9, -4, 7, 6, 5, 4, 3, 2, 1, 0};
    s2.Sort(arr_2, 10);
    printArray(arr_2, 10);

    cout << endl;

    Testbed tester;

    cout << "Selection Sorter---->Random Case:" << endl;
    tester.RunExperiment(&s1, 0, 1, 100000, 1000, 20000, 100, 1000);

    cout << endl;

    cout << "Quick Sorter ----> Random Case:" << endl;
    tester.RunExperiment(&s2, 0, 1, 100000, 1000, 20000, 100, 1000);

    cout << endl;

    cout << "Selection Sorter ----> Reversed Case:" << endl;
    tester.RunExperiment(&s1, 1, 1, 100000, 1000, 20000, 100, 1000);

    cout << endl;

    cout << "Quick Sorter ----> Reversed Case:" << endl;
    tester.RunExperiment(&s2, 1, 1, 100000, 1000, 20000, 100, 1000);


    return 0;
}
