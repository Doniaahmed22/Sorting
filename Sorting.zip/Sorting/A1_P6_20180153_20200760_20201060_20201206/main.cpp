///problem 6
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
using namespace std;
class  PhoneDirectory
{
    struct Phone
    {
        string Phone_Number_Entry;
        Phone*Next_Phone;
    };
    struct Entry
    {
        string First_Name,Last_Name;
        Phone*First_Phone;
        Phone*Last_Phone;
        int Number_Of_Phone_Number;
        Entry*Next_Entry;
    };
    int Number_Of_Entry;
    Entry*First_Entry;
    Entry*Last_Entry;
public:
    PhoneDirectory()
    {
        Number_Of_Entry=0;
        First_Entry=NULL;
        Last_Entry=NULL;
    }
    string Word_to_Modify(string n)
    {
        for(int i=0; i<n.length(); i++)
            if(i == 0)
                n[0]=toupper(n[0]);
            else
                n[i]=tolower(n[i]);
        return n;
    }
    Entry*searchEntry(string f,string l)
    {
        Entry*current=First_Entry;
        while(current != NULL)
        {
            if(current->First_Name == f&&current->Last_Name == l)
                return current;
            current=current->Next_Entry;
        }
        return NULL;
    }
    Phone*searchPhone(Phone* F,string p)
    {
        Phone*current=F;
        while(current != NULL)
        {
            if(current->Phone_Number_Entry == p)
                return current;
            current=current->Next_Phone;
        }
        return NULL;
    }
    void Add_an_entry_to_the_directory(string f_name,string l_name,string p_number)
    {
        f_name=Word_to_Modify(f_name);
        l_name=Word_to_Modify(l_name);
        Entry*FoundEntry=searchEntry(f_name,l_name);
        if(FoundEntry == NULL)
        {
            FoundEntry = new Entry();
            FoundEntry->First_Name=f_name;
            FoundEntry->Last_Name=l_name;
            Phone*NewPhone;
            NewPhone=new Phone();
            NewPhone->Phone_Number_Entry=p_number;
            if(First_Entry == NULL)
            {
                First_Entry = FoundEntry;
                Last_Entry = FoundEntry;
                FoundEntry->Next_Entry=NULL;
            }
            else
            {
                FoundEntry->Next_Entry=NULL;
                Last_Entry->Next_Entry=FoundEntry;
                Last_Entry=FoundEntry;
            }
            if(FoundEntry->First_Phone == NULL)
            {
                FoundEntry->First_Phone=NewPhone;
                FoundEntry->Last_Phone=NewPhone;
                NewPhone->Next_Phone=NULL;
            }
            else
            {
                NewPhone->Next_Phone=NULL;
                FoundEntry->Last_Phone->Next_Phone=NewPhone;
                FoundEntry->Last_Phone=NewPhone;
            }
            Number_Of_Entry++;
            FoundEntry->Number_Of_Phone_Number++;
            cout<<"  Done Added"<<endl;
        }
        else
        {
            Phone*FoundPhone=searchPhone(FoundEntry->First_Phone,p_number);
            if(FoundPhone == NULL)
            {
                FoundPhone=new Phone();
                FoundPhone->Next_Phone=NULL;
                FoundPhone->Phone_Number_Entry=p_number;
                FoundEntry->Last_Phone->Next_Phone=FoundPhone;
                FoundEntry->Last_Phone=FoundPhone;
                FoundEntry->Number_Of_Phone_Number++;
                cout<<"  The First Name and Last Name is Found in Phone Directory \n";
                cout<<"  but The Phone Number is not Found and Done Added The Phone Number. "<<endl;
            }
            else
                cout<<"  The Phone Number is already Found"<<endl;
        }
    }
    void Delete_an_entry_from_the_directory(string f_name)
    {
        f_name=Word_to_Modify(f_name);
        bool found=false;
        Entry*del=First_Entry,*current;
        while(del != NULL)
        {
            if(del->First_Name != f_name)
            {
                current=del;
                del=del->Next_Entry;
            }
            else
            {
                if(del == First_Entry && del == Last_Entry)
                {
                    First_Entry=Last_Entry=NULL;
                    delete del;
                    del=NULL;
                }
                else if(del == Last_Entry)
                {
                    Last_Entry=current;
                    Last_Entry->Next_Entry=NULL;
                    delete del;
                    del=NULL;
                }
                else if(del == First_Entry)
                {
                    First_Entry=del->Next_Entry;
                    delete del;
                    del=First_Entry;
                }
                else
                {
                    current->Next_Entry=del->Next_Entry;
                    delete del;
                    del=current->Next_Entry;
                }
                Number_Of_Entry--;
                found=true;
            }
        }
        if(found == false)
            cout<<"  There is not such as "<<f_name<<" in Phone Directory"<<endl;
    }
    void Look_up_by_first_name(string f_name)
    {
        bool condition=false;
        int i=0,j=0;
        Entry*current=First_Entry;
        while(current != NULL)
        {
            if(current->First_Name == f_name)
            {
                cout<<"  The First Name is Found ( "<<++i<<" )"<<endl;
                cout<<"  First Name     : "<<current->First_Name<<endl;
                cout<<"  Last Name      : "<<current->Last_Name<<endl;
                Phone*Phone_number;
                for(Phone_number=current->First_Phone; Phone_number!=NULL; Phone_number=Phone_number->Next_Phone)
                    cout<<"  Phone Number  "<<++j<<" : "<<Phone_number->Phone_Number_Entry<<endl;
                cout<<"  ------------------------"<<endl;
                condition=true;
            }
            current=current->Next_Entry;
        }
        if(condition == false)
            cout<<"**There is not such as "<<f_name<<" in Phone Directory"<<endl;
    }
    void Look_up_a_phone_number(string p_number)
    {
        bool condition=false;
        Entry*current=First_Entry;
        while(current != NULL)
        {
            Phone*Found=current->First_Phone;
            while(Found != NULL)
            {
                if(Found->Phone_Number_Entry == p_number)
                {
                    cout<<"  The Phone Number is Found"<<endl;
                    cout<<"  First Name   : "<<current->First_Name<<endl;
                    cout<<"  Last Name    : "<<current->Last_Name<<endl;
                    cout<<"  Phone Number : "<<Found->Phone_Number_Entry<<endl<<endl;
                    condition = true;
                    break;
                }
                else
                    Found=Found->Next_Phone;
            }
            if (condition == false)
                current=current->Next_Entry;
            else
                break;
        }
        if(condition == false)
            cout<<"**There is not such as "<<p_number<<" in Phone Directory"<<endl;
    }
    void List_All_entries_in_phone_directory()
    {
        this->BubbleSort();
        int i=0;
        if(First_Entry != NULL)
        {
            Entry*current=First_Entry;
            while(current != NULL)
            {
                cout<<"  Entry : "<<++i <<endl;
                cout<<"  First Name      : "<<current->First_Name<<endl;
                cout<<"  Last Name       : "<<current->Last_Name<<endl;
                Phone*Phone=current->First_Phone;
                for(int i=0; i<current->Number_Of_Phone_Number; i++,Phone=Phone->Next_Phone)
                    cout<<"  Phone Number  "<<i+1<<" : "<<Phone->Phone_Number_Entry<<endl;
                cout<<"  -----------"<<endl;
                current=current->Next_Entry;
            }
        }
        else
            cout<<"  Phone Directory Is Empty"<<endl;
    }
    void SelectionSort()
    {
        Entry*current=First_Entry,*previous_current=NULL,*least=current,*previous_least=NULL,*next=current;
        while(current->Next_Entry != NULL )
        {
            while(next->Next_Entry != NULL)
            {
                if(least->First_Name > next->Next_Entry->First_Name)
                {
                    previous_least=next;
                    least = next->Next_Entry;
                }
                next=next->Next_Entry;
            }
            if(previous_least != NULL)
            {
                if(current == least)
                {
                    previous_current=current;
                    previous_least=least;
                    current=current->Next_Entry;
                    least=current;
                    next=current;
                }
                else
                {
                    previous_least->Next_Entry=least->Next_Entry;
                    if(least == Last_Entry)
                        Last_Entry=previous_least;
                    if(previous_current == NULL)
                    {
                        least->Next_Entry=current;
                        First_Entry=least;
                        previous_current=First_Entry;
                    }
                    else
                    {
                        least->Next_Entry=previous_current->Next_Entry;
                        previous_current->Next_Entry=least;
                        previous_current=previous_current->Next_Entry;
                    }
                    previous_least=least;
                    least=current;
                    next=current;
                }
            }
            else
            {
                previous_current=current;
                previous_least=least;
                current=current->Next_Entry;
                least=current;
                next=current;
            }
        }
    }
    void BubbleSort()
    {
        Entry*last=NULL,*n,*current,*tailcurrent,*temp;
        while(last != First_Entry->Next_Entry)
        {
            n=current=First_Entry;
            while( current->Next_Entry!= last)
            {
                tailcurrent=current->Next_Entry;
                if(current->First_Name > tailcurrent->First_Name)
                {
                    current->Next_Entry=tailcurrent->Next_Entry;
                    tailcurrent->Next_Entry=current;
                    if(current != First_Entry)
                        n->Next_Entry=tailcurrent;
                    else
                        First_Entry=tailcurrent;
                    temp=current;
                    current=tailcurrent;
                    tailcurrent=temp;
                }
                n=current;
                current=current->Next_Entry;
            }
            last=current;
        }
    }
    Entry* divide_from(Entry*sub_list)
    {
        Entry*midpoint = sub_list,*position,*second_half;
        if( midpoint ==  NULL)
            return NULL;
        position=midpoint->Next_Entry;
        while( position != NULL)
        {
            position=position->Next_Entry;
            if(position != NULL)
            {
                midpoint=midpoint->Next_Entry;
                position=position->Next_Entry;
            }
        }
        second_half=midpoint->Next_Entry;
        midpoint->Next_Entry=NULL;
        return second_half;
    }
    Entry*merge(Entry*first,Entry*second)
    {
        Entry*last_sorted,combined;
        last_sorted=&combined;
        while(first != NULL&&second != NULL)
        {
            if(first->First_Name <= second->First_Name)
            {
                last_sorted->Next_Entry=first;
                last_sorted=first;
                first=first->Next_Entry;
            }
            else
            {
                last_sorted->Next_Entry=second;
                last_sorted=second;
                second=second->Next_Entry;
            }
        }
        if(first == NULL)
            last_sorted->Next_Entry=second;
        else
            last_sorted->Next_Entry=first;

        return combined.Next_Entry;
    }
    void recursive_merge_sort(Entry* &sub_list)
    {
        if(sub_list != NULL&&sub_list->Next_Entry != NULL)
        {
            Entry*second_half=divide_from(sub_list);
            recursive_merge_sort(sub_list);
            recursive_merge_sort(second_half);
            sub_list=merge(sub_list,second_half);
        }
    }
    void mergeSort()
    {
        recursive_merge_sort(First_Entry);
    }
    void insertSort()
    {
        Entry*first_unsorted,*last_sorted,*current,*trailing;
        if(First_Entry != NULL)
        {
            last_sorted=First_Entry;
            while(last_sorted->Next_Entry != NULL)
            {
                first_unsorted=last_sorted->Next_Entry;
                if(first_unsorted->First_Name < First_Entry->First_Name)
                {
                    last_sorted->Next_Entry=first_unsorted->Next_Entry;
                    first_unsorted->Next_Entry=First_Entry;
                    First_Entry=first_unsorted;
                }
                else
                {
                    trailing=First_Entry;
                    current=trailing->Next_Entry;
                    while(first_unsorted->First_Name > current->First_Name)
                    {
                        trailing=current;
                        current=trailing->Next_Entry;
                    }
                    if(first_unsorted == current)
                        last_sorted=first_unsorted;
                    else
                    {
                        last_sorted->Next_Entry=first_unsorted->Next_Entry;
                        first_unsorted->Next_Entry=current;
                        trailing->Next_Entry=first_unsorted;
                    }
                }
            }
        }

    }
    ~PhoneDirectory()
    {
        Entry*deleteEntry = First_Entry;
        while(deleteEntry != NULL)
        {
            First_Entry=First_Entry->Next_Entry;
            Phone*deletePhone=deleteEntry->First_Phone;
            while(deletePhone != NULL)
            {
                deleteEntry->First_Phone=deleteEntry->First_Phone->Next_Phone;
                delete deletePhone;
                deletePhone=deleteEntry->First_Phone;
            }
            delete deleteEntry;
            deleteEntry=First_Entry;
        }
    }
};

int main()
{
    int num = 1;
    string s1,s2,s3;
    PhoneDirectory phone;
    cout << " 1. Add an entry to the directory\n 2. Look up a phone number\n";
    cout << " 3. Look up by first name\n 4. Delete an entry from the directory\n";
    cout << " 5. List All entries in phone directory\n 6. Exit form this program" << endl;
    while(num <=5&&num>0)
    {
        cout<<endl<<" Choose From a Menu Of Options : ";
        cin>>num;
        cout<<endl;
        if(num==1)
        {
            cout<<"* Add an entry to the directory"<<endl;
            cout<<"  -----------------------------"<<endl;
            cout<<"  Enter First Name : ";
            cin>>s1;
            cout<<"  Enter Last Name : ";
            cin>>s2;
            cout<<"  Enter Phone Number : ";
            cin>>s3;
            phone.Add_an_entry_to_the_directory(s1,s2,s3);
        }
        else if(num==2)
        {
            cout<<"* Look up a phone number"<<endl;
            cout<<"  ----------------------"<<endl;
            cout<<"  Enter Phone Number : ";
            cin>>s1;
            phone.Look_up_a_phone_number(s1);
        }
        else if(num==3)
        {
            cout<<"* Look up by first name"<<endl;
            cout<<"  ---------------------"<<endl;
            cout<<"  Enter First Name : ";
            cin>>s1;
            phone.Look_up_by_first_name(s1);
        }
        else if(num==4)
        {
            cout<<"* Delete an entry from the directory"<<endl;
            cout<<"  ----------------------------------"<<endl;
            cout<<"  Please,Enter First Name that you want to delete : ";
            cin>>s1;
            phone.Delete_an_entry_from_the_directory(s1);
        }
        else if(num == 5)
        {
            cout<<"* List All entries in phone directory"<<endl;
            cout<<"  -----------------------------------"<<endl;
            phone.List_All_entries_in_phone_directory();
        }
    }
    return 0;
}
