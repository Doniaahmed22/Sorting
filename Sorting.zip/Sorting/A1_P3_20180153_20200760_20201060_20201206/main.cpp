///problem 3
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include"Matrix.h"
using namespace std;
template<class T>
class MatrixCalculator
{
public:
    void Menue()
    {
        int Number_of_choice,row,column;
        cout<<" Welcome to (Your Name) Matrix Calculator\n";
        cout<<" ----------------------------------------"<<endl;
        cout<<"  1- Perform Matrix Addition.\n";
        cout<<"  2- Perform Matrix Subtraction.\n";
        cout<<"  3- Perform Matrix Multiplication.\n";
        cout<<"  4- Matrix Transpose.\n  5- Exit.\n"<<endl;
        cout<<"  choose the number from the Menu : ";
        cin>>Number_of_choice;
        cout<<endl;
        while(Number_of_choice < 5&& Number_of_choice > 0)
        {
            if(Number_of_choice == 1)
            {
                cout<<"* Perform Matrix Addition "<<endl;
                cout<<"  Enter (Row,Column) of Matrix 1 and Matrix 2 : ";
                cin>>row>>column;
                if(row > 0&&column>0)
                {
                    Matrix<T>m1(row,column),m2(row,column),m3(row,column);
                    cout<<"  Enter Matrix 1 "<<endl;
                    cin>>m1;
                    cout<<"  Enter Matrix 2 "<<endl;
                    cin>>m2;
                    m3=m1+m2;
                    cout<<"  Matrix 1 + Matrix 2 "<<endl;
                    cout<<"  ------------------- "<<endl;
                    cout<<m3;
                }
                else
                    cout<<"  Input Error "<<endl;
            }
            else if (Number_of_choice == 2)
            {
                cout<<"* Perform Matrix Subtraction "<<endl;
                cout<<"  Enter (Row,Column) of Matrix 1 and Matrix 2 : ";
                cin>>row>>column;
                if(row >0&&column>0)
                {
                    Matrix<T>m1(row,column),m2(row,column),m3(row,column);
                    cout<<"  Enter Matrix 1 "<<endl;
                    cin>>m1;
                    cout<<"  Enter Matrix 2 "<<endl;
                    cin>>m2;
                    m3=m1-m2;
                    cout<<"  Matrix 1 - Matrix 2 "<<endl;
                    cout<<"  ------------------- "<<endl;
                    cout<<m3;
                }
                else
                    cout<<"  input Error "<<endl;
            }
            else if(Number_of_choice == 3)
            {
                int row1,column1;
                cout<<"* Perform Matrix Multiplication "<<endl;
                cout<<"  Enter (Row,Column) of Matrix 1 : ";
                cin>>row>>column;
                cout<<"  Enter (Row,Column) of Matrix 2: ";
                cin>>row1>>column1;
                if(column == row1&&row>0&&column>0&&row1>0&&column1>0)
                {
                    Matrix<T>m1(row,column),m2(row1,column1),m3(row,column1);
                    cout<<"  Enter Matrix 1"<<endl;
                    cin>>m1;
                    cout<<"  Enter Matrix 2"<<endl;
                    cin>>m2;
                    m3=m1*m2;
                    cout<<"  Matrix 1 * Matrix 2 "<<endl;
                    cout<<"  ------------------- "<<endl;
                    cout<<m3;
                }
                else
                    cout<<"  Error, Column of Matrix 1 Should equal Row of Matrix 2 . \n  OR \n  Input Error "<<endl;

            }
            else if(Number_of_choice == 4)
            {
                cout<<"* Matrix Transpose "<<endl;
                cout<<"  Enter (Row,Column) of Matrix : ";
                cin>>row>>column;
                if(row>0&&column>0)
                {
                    Matrix<T>m1(row,column),m2(column,row);
                    cout<<"  Enter Matrix "<<endl;
                    cin>>m1;
                    m2=m1.Transpose();
                    cout<<" Transpose(Matrix) "<<endl;
                    cout<< " -----------------"<<endl;
                    cout<<m2;
                }
                else
                    cout<<"  Input Error"<<endl;
            }
            cout<<"  choose the number from the Menu : ";
            cin>>Number_of_choice;
            cout<<endl;
        }
    }
};
int main()
{
    MatrixCalculator<int> m;
    m.Menue();
    return 0;
}
