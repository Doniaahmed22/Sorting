#ifndef MATRIX_H_INCLUDED
#define MATRIX_H_INCLUDED
#include<iostream>
using namespace std;
template<class T>
class Matrix
{
private:
    int Row,Column;
    T **Element;
public:
    Matrix(int r,int c)
    {
        this->Row=r;
        this->Column=c;
        this->Element=new T*[this->Row];
        for(int i=0; i<this->Row; i++)
            this->Element[i]=new T[this->Column];
    }
    Matrix operator+(Matrix&obj)
    {
        Matrix<T> m(obj.Row,obj.Column);
        for(int i=0; i<obj.Row; i++)
            for(int j=0; j<obj.Column; j++)
                m.Element[i][j]=obj.Element[i][j]+this->Element[i][j];
        return m;
    }
    Matrix operator-(Matrix&obj)
    {
        Matrix m(obj.Row,obj.Column);
        for(int i=0; i<obj.Row; i++)
            for(int j=0; j<obj.Column; j++)
                m.Element[i][j]=this->Element[i][j]-obj.Element[i][j];
        return m;
    }
    Matrix operator*(Matrix&obj)
    {
        Matrix m(this->Row,obj.Column);
        for(int i=0; i<this->Row; i++)
            for(int j=0; j<obj.Column; j++)
            {
                m.Element[i][j]=0;
                for(int k=0; k<obj.Row; k++)
                    m.Element[i][j]+=this->Element[i][k]*obj.Element[k][j];
            }
        return m;
    }
    Matrix Transpose()
    {
        Matrix m(this->Column,this->Row);
        for(int i=0; i<this->Row; i++)
            for(int j=0; j<this->Column; j++)
                m.Element[j][i]=this->Element[i][j];
        return m;
    }
    ~Matrix()
    {
        for(int i=0; i<this->Row; i++)
            delete[]this->Element[i];
        delete []this->Element;
    }
    friend istream&operator>>(istream&is,Matrix&obj)
    {
        for(int i=0; i<obj.Row; i++)
            for(int j=0; j<obj.Column; j++)
                is>>obj.Element[i][j];
        return is;
    }
    friend ostream&operator<<(ostream&os,Matrix&obj)
    {
        for(int i=0; i<obj.Row; i++)
        {
            os<<" ";
            for(int j=0; j<obj.Column; j++)
                os<<obj.Element[i][j]<<" ";
            os<<endl;
        }
        os<<endl;
        return os;
    }
};
#endif // MATRIX_H_INCLUDED
