///problem 7
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

bool sorting(string first_song, string second_song)
{
    if (first_song == "Untitled" && second_song != "Untitled")
    {
        return 1;
    }
    else
    {
        if (first_song != "Untitled" && second_song == "Untitled")
        {
            return 0;
        }
        else
        {
            return first_song < second_song;
        }
    }
}

void BiasedSort(vector<string>& songList)
{
    bool swapped = true;
    while (swapped)
    {
        swapped = false;
        for (unsigned int i = 1; i != songList.size(); i++)
        {
            if (sorting(songList[i], songList[i - 1]))
            {
                swap(songList[i], songList[i - 1]);
                swapped = true;
            }
        }
    }
}
void BiasedSort_STL(vector<string>& songList)
{
    sort(songList.begin(), songList.end(), sorting);
}

void print(vector<string> songList)
{
    for (unsigned int i = 0; i != songList.size(); i++)
    {
        cout << songList[i] <<endl;
    }
    cout << endl;
}

int main()
{
    vector<string> song_list;
    song_list.push_back("Untitled");
    song_list.push_back("A");
    song_list.push_back("Untitled");
    song_list.push_back("C");
    song_list.push_back("Untitled");

    BiasedSort(song_list);

    cout << "Song List :\n";
    print(song_list);



    return 0;
}
