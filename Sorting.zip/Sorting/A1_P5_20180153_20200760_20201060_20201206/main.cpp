///problem 5
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include <string>
#include<vector>
using namespace std;

class StudentName
{
public:
    string name;
    StudentName() {}
    StudentName(string x)
    {
        int space=0;
        int indexOfSpace=0;

        for(int i=0; i<x.length(); i++)
        {
            if(x[i]==' ')
            {
                space+=1;
                indexOfSpace=i;
            }
        }

        if(space>=2)
        {
            name=x;
        }
        if(space==1)
        {
            name=x+x.substr(indexOfSpace);
        }

        if(space==0)
        {
            name=x+" "+x+" "+x;
        }
    }
    void print()
    {
        vector <string> Names; ///end in this scope
        string part="";
        for(int i=0; i<name.length(); ++i)
        {
            if (name[i]==' ')
            {
                Names.push_back(part);
                part="";
            }
            else if(i==name.length()-1)
            {
                part+=name[i];
                Names.push_back(part);
            }
            else
                part+=name[i];/// donia .. ahmed
        }
        int j=1;
        cout<<"the name is : "<<endl;
        for(int i=0; i<Names.size(); ++i)
        {
            cout<<j<<") "<<Names[i]<<endl;
            j++;
        }
        cout<<endl;
    }
    bool Replace(int i,int j)
    {
        vector <string> Names;
        string part="";
        for(int i=0; i<name.length(); ++i)
        {
            if (name[i]==' ')
            {
                Names.push_back(part);
                part="";
            }
            else if(i==name.length()-1)
            {
                part+=name[i];
                Names.push_back(part);
            }
            else
                part+=name[i];
        }

        if(i > Names.size() || j > Names.size() || i<1 || j<1)
        {
            cout<<"invalid position --> not replaced \n"<<endl;
            return false;
        }
        else
        {
            string temp=Names[j-1];
            Names[j-1]=Names[i-1];
            Names[i-1]=temp;
            string replacedName ="";
            for(int i = 0 ; i < Names.size() ; i++)
            {
                replacedName+=Names[i] + " ";
            }
            name = replacedName;
            return true;
        }
    }
};
int main()
{
    /// the fist test
    StudentName s1("Donia Ahmed Abozied Mohamed");
    cout<<"Before replacement "<<endl;
    s1.print();
    s1.Replace(2,3);
    cout<<"After replacement "<<endl;
    s1.print();
    cout<<"----------------------------------------------\n"<<endl;
    /// the second test
    StudentName s2("Hager Mohamed");
    cout<<"Before replacement "<<endl;
    s2.print();
    s2.Replace(1,2);
    cout<<"After replacement "<<endl;
    s2.print();
    cout<<"----------------------------------------------\n"<<endl;
    /// the third test
    StudentName s3("Abd_Elrahman");
    cout<<"Before replacement "<<endl;
    s3.print();
    s3.Replace(0,2);
    cout<<"After replacement "<<endl;
    s3.print();
    cout<<"----------------------------------------------\n"<<endl;
    /// the forth test
    StudentName s4("Youssef Ahmed Abozied");
    cout<<"Before replacement "<<endl;
    s4.print();
    s4.Replace(1,3);
    cout<<"After replacement "<<endl;
    s4.print();
    cout<<"----------------------------------------------\n"<<endl;
    /// the fifth test
    StudentName s5("Mohamed");
    cout<<"Before replacement "<<endl;
    s5.print();
    s5.Replace(1,5);
    cout<<"After replacement "<<endl;
    s5.print();
    return 0;
}

