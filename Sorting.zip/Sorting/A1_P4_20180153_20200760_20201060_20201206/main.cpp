///problem 4
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include <set>
#include <string>
using namespace std;

void modifiedPermute(set<string>& theSet, string soFar, string my_word)
{
    if (my_word == "")
        theSet.insert(soFar);
    else
        for (unsigned int i = 0; i < my_word.length(); i++)
        {
            string next = soFar + my_word[i];
            string remaining = my_word.substr(0, i) + my_word.substr(i + 1);
            modifiedPermute(theSet, next, remaining);
        }
}

void ListOfPermutations(string s)
{
    set<string> theSet;
    modifiedPermute(theSet, "", s);
    for (set<string>::iterator it = theSet.begin(); it != theSet.end(); it++)
    {
        cout << *it << endl;
    }
}

int main()
{
    ListOfPermutations("Abb");
    return 0;
}
