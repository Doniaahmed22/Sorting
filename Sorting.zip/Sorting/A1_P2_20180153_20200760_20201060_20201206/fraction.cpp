#include "fraction.h"
#include <iostream>
#include<vector>
using namespace std;

 void fraction :: simplify ()
  {
      for (int i=10;i>0;)
      {
          int res1=up; ///5
          int res2=down; ///10
          if(res1 %i ==0 && res2 %i ==0)
          {
              up=up/i;
              down=down/i;
              //cout<<i<<endl;
            break;
          }
          else
          i--;

      }
  }


fraction :: fraction(double y,double z)
    {
        up=y;
        down=z;
    }

 fraction ::fraction(){}
///operator overloading
bool val=0;
fraction fraction:: operator*(const fraction & obj)
{
  fraction result;
  result.up=up*obj.up;
  result.down=down*obj.down;
  result.simplify();
   //cout<<result<<endl;
   return result;
}

  fraction fraction:: operator/(const fraction & obj)
  {
  fraction result;
  result.up=up*obj.down;
  result.down=down*obj.up;
  result.simplify();
   //cout<<result<<endl;
   return result;
  }

  fraction fraction::operator+(const fraction & obj)
  {
   fraction result;

  if(down==obj.down)
  {
      result.up=up+obj.up;
      result.down=down;
      result.simplify();
      return result;
  }
  else
   {
   result.up=up*obj.down+down*obj.up;
   result.down=down*obj.down;
   //cout<<result.up<<" "<<result.down;
   result.simplify();
   return result;
   }
  }

   fraction fraction::operator-(const fraction & obj)
  {

      fraction result;
   if(down==obj.down)
  {
     if(up>obj.up)
     {
      result.up=up-obj.up;
      result.down=down;
      result.simplify();
      return result;
     }

     else
     {

         cout<<"this is a negative value"<<endl;
         val=1;
     }

  }

  else
   {
   fraction result1;
   fraction result2;
   result1.up=up;
   result1.down=down;
   result2.up=obj.up;
   result2.down=obj.down;
   if(result1>result2)
   {
      result.up=up*obj.down-down*obj.up;
   result.down=down*obj.down;
   //cout<<result.up<<" "<<result.down;
   result.simplify();
   return result;
   }
        else
     {
         cout<<"this is a negative value"<<endl;
     val=1;
     }

   }
  }

  bool fraction::operator<(const fraction & obj)
  {
    double res1=up/down;
    double res2=obj.up/obj.down;
    if(res1<res2)
        return true;
    else
        return false;
  }
  bool fraction::operator>(const fraction & obj)
  {
      double res1=up/down;
    double res2=obj.up/obj.down;
    if(res1>res2)
        return true;
    else
        return false;
  }
  bool fraction::operator==(const fraction & obj)
  {
      double res1=up/down;
    double res2=obj.up/obj.down;
    if(res1==res2)
        return true;
    else
        return false;
  }
  bool fraction::operator<=(const fraction & obj)
  {
      double res1=up/down;
    double res2=obj.up/obj.down;
    if(res1<=res2)
        return true;
    else
        return false;
  }
  bool fraction::operator>=(const fraction & obj)
  {
      double res1=up/down;
    double res2=obj.up/obj.down;
    if(res1>=res2)
        return true;
    else
        return false;
  }
ostream& operator<<(ostream& os,const fraction & obj)
{
    if(val!=1){
    os <<endl<<obj.up<<"/"<<obj.down;}
    else
    {

    }
    return os;
}
istream& operator>>(istream& is, fraction & obj)
{
    is >> obj.up>>obj.down;
    return is;
}


/*fraction::fraction()
{
    //ctor
}

fraction::~fraction()
{
    //dtor
}*/
