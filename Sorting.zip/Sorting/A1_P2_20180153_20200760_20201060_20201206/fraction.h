#ifndef FRACTION_H_INCLUDED
#define FRACTION_H_INCLUDED
#include "fraction.h"
#include <iostream>
using namespace std;

class fraction
{
    public:
        double up,down;
        fraction();
        fraction(double y,double z);
        fraction operator+(const fraction & obj);
        fraction operator-(const fraction & obj);
        fraction operator*(const fraction & obj);
        fraction operator/(const fraction & obj);
        bool operator<(const fraction & obj);
        bool operator>(const fraction & obj);
        bool operator==(const fraction & obj);
        bool operator<=(const fraction & obj);
        bool operator>=(const fraction & obj);
        void simplify ();
        friend ostream& operator<<(ostream& os,const fraction & obj);
        friend istream& operator>>(istream& is, fraction & obj);
        //virtual ~fraction();

    protected:

    private:
};


#endif // FRACTION_H_INCLUDED
