///problem 2
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include "fraction.h"
#include <iostream>
#include<vector>
using namespace std;

int main()
{

    fraction f1, f2,f3;
    vector <fraction>recentlyResult;
    cout<<"enter the first fraction number"<<endl;
    cin>>f1;
    cout<<"enter the second fraction number"<<endl;
    cin>>f2;
    cout<<"\nchoose the operation that you need "<<endl;
    cout<<" 1  ->   + "<<endl;
    cout<<" 2  ->   - "<<endl;
    cout<<" 3  ->   * "<<endl;
    cout<<" 4  ->   / "<<endl;
    cout<<" 5  ->   < "<<endl;
    cout<<" 6  ->   > "<<endl;
    cout<<" 7  ->   <= "<<endl;
    cout<<" 8  ->   >= "<<endl;
    cout<<" 9  ->   == "<<endl;
    cout<<" 10 ->   exit \n"<<endl;
    int x;

    while(x!=10)
    {
        cin>>x;
        switch(x)
        {

        case 1 :
            f3=f1+f2;
            cout<<"the result is : "<<f3<<endl<<endl;
            recentlyResult.push_back(f3);
            break;
        case 2 :
            f3=f1-f2;
            cout<<"the result is : "<<f3<<endl<<endl;
            recentlyResult.push_back(f3);
            break;
        case 3 :
            f3=f1*f2;
            cout<<"the result is : "<<f3<<endl<<endl;
            recentlyResult.push_back(f3);
            break;
        case 4 :
            f3=f1/f2;
            cout<<"the result is : "<<f3<<endl<<endl;
            recentlyResult.push_back(f3);
            break;
        case 5 :
            if(f1<f2)
                cout<<"the result is : "<<"\ntrue\n"<<endl<<endl;
            else
                cout<<"the result is : "<<"\nfalse\n"<<endl<<endl;

            break;
        case 6 :
            if(f1>f2)
                cout<<"the result is : "<<"\ntrue\n"<<endl<<endl;
            else
                cout<<"the result is : "<<"\nfalse\n"<<endl<<endl;
            break;
        case 7 :
            if(f1<=f2)
                cout<<"the result is : "<<"\ntrue\n"<<endl<<endl;
            else
                cout<<"the result is : "<<"\nfalse\n"<<endl<<endl;
            break;
        case 8 :
            if(f1>=f2)
                cout<<"the result is : "<<"\ntrue\n"<<endl<<endl;
            else
                cout<<"the result is : "<<"\nfalse\n"<<endl<<endl;
            break;
        case 9 :
            if(f1==f2)
                cout<<"the result is : "<<"\ntrue\n"<<endl<<endl;
            else
                cout<<"the result is : "<<"\nfalse\n"<<endl<<endl;
            break;
        case 10:
            cout<<"you closed the program"<<endl<<endl;
            break;
        default:
            cout<<endl<<"this is invalid number\n"<<endl;
            break;
        }
    }
/// the recently results that you get it
    /*
    cout<<"the recently results that you get it"<<endl;
    for(int i=0;i<recentlyResult.size();i++)
    {
        cout<<recentlyResult[i];
    }
    */
    cout<<"thank you for using the fraction calculator\n";


    return 0;
}
