//
// Created by AbdOo on 4/23/2022.
//

#ifndef A1_P8_SORTER_H
#define A1_P8_SORTER_H



class Sorter {
public:
    Sorter();
    virtual void Sort(int* array, int size) = 0;

};

#endif //A1_P8_SORTER_H
