///problem 8
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
#include "test.h"
#include "Insertion.h"
using namespace std;
int main ()
{
    test tester;

    Insertion s1(INSERTION);
    cout << "Normal Insertion Sorter:" << endl;
    tester.RunExperiment(&s1, 0, 1, 1000000, 1000, 20000, 1000, 1000);

    cout << endl;

    Insertion s2(BINARY);
    cout << "Binary Insertion Sorter:" << endl;
    tester.RunExperiment(&s2, 0, 1, 1000000, 1000, 20000, 100, 1000);

    return 0;
}
