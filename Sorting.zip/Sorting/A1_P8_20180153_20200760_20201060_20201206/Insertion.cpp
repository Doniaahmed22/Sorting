//
// Created by AbdOo on 4/23/2022.
//

#include "Insertion.h"
Insertion::Insertion(int iType)
        : type(iType) {

}

void Insertion::insertionSort(int* array, int size) {
    for (int i = 1; i != size; i++) {
        int insert = array[i];
        int j = i;
        while(j != 0 && insert < array[j - 1]) {
            array[j] = array[j - 1];
            j--;
        }
        array[j] = insert;
    }
}


void Insertion::insertionSort_BinarySearch(int* array, int size){
    for (int i = 1; i < size; i++) {
        int insert = array[i];
        int beg = 0, end = i;
        while (beg < end) {
            int mid = (beg + end) / 2;
            if (insert <= array[mid]) {
                end = mid;
            }
            else {
                beg = mid + 1;
            }
        }

        for (int j = i; j > end; j--)
            array[j] = array[j - 1];

        array[beg] = insert;
    }
}

void Insertion::Sort(int* array, int size) {
    if (type == INSERTION)         { insertionSort(array, size);          }
    else if (type == BINARY)    { insertionSort_BinarySearch(array, size);    }
}

