//
// Created by AbdOo on 4/23/2022.
//
#include "Sorter.h"

#ifndef A1_P8_INSERTION_H
#define A1_P8_INSERTION_H

enum SORT_TYPE {
    INSERTION,
    BINARY
};

class Insertion : public Sorter {
private:
    int type;

    void insertionSort(int* array, int size);
    void insertionSort_ByTwo(int* array, int size);
    void insertionSort_BinarySearch(int* array, int size);

public:
    Insertion(int iType = 0);
    void Sort(int* array, int size);
};


#endif //A1_P8_INSERTION_H
