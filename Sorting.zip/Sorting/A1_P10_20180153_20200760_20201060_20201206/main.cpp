///problem 10
/// donia ahmed abozied mohammed 20201060
/// hager mohammed abdelhalem ghareb 20201206
/// abdelrahman taha abdelbar 20180153
/// ziad adel sayyad mohammed 20200760
#include <iostream>
using namespace std;
template <class type>
class list
{
public:
    int size_of_list;
    class Node
    {
    public:
        friend class list;
        type data;
        Node *Next, *Previous;
    };
    Node *First, *Last;

public:
    class iterator
    {
    public:
        Node *node_iterator;
        bool begin_list;
        friend class list;
        friend class Node;

    public:
        iterator(Node *newPtr=NULL,bool b=false)
        {
            node_iterator = newPtr;
            begin_list=b;
        }
        bool operator==(const iterator &it) const
        {
            return node_iterator == it.node_iterator;
        }
        iterator operator++(int)
        {
            iterator temp = *this;
            if(node_iterator->Next != NULL)
                node_iterator = node_iterator->Next;
            return temp;
        }
        iterator operator--(int)
        {
            iterator temp = *this;
            if(node_iterator->Previous != NULL)
                node_iterator = node_iterator->Previous;
            return temp;
        }
        iterator operator++()
        {
            if(node_iterator->Next != NULL)
                node_iterator = node_iterator->Next;
            return node_iterator;
        }
        iterator operator--()
        {
            if(node_iterator->Previous != NULL)
                node_iterator = node_iterator->Previous;
            return node_iterator;
        }
        type&operator * ()
        {
            return node_iterator->data;
        }

    };
    void push_back(type value)
    {
        Node *newnode = new Node();
        newnode->data = value;
        newnode->Next = NULL;
        if(First == NULL)
        {
            First=newnode;
            Last=newnode;
            newnode->Previous=NULL;
        }
        else
        {
            Last->Next = newnode;
            newnode->Previous = Last;
            Last=newnode;
        }
        size_of_list++;
    }
    list()
    {
        First = Last = NULL;
        size_of_list=0;
    }
    list(type value, int initial_size)
    {
        size_of_list = initial_size;
        Node *newnode = new Node();
        newnode->data = value;
        newnode->Next=NULL;
        newnode->Previous=NULL;
        First=newnode;
        Last=newnode;
    }
    iterator begin() const
    {
        return iterator(First,true);
    }

    iterator end() const
    {
        return iterator(Last);
    }
    int size()
    {
        cout<<size_of_list<<endl;
        size_of_list = 0;
        Node *current = this->First;
        while (current != NULL)
        {
            size_of_list++;
            current = current->Next;
        }
        return size_of_list;
    }
    ~list()
    {
        while (First != NULL)
        {
            Node*current=First;
            First = First->Next;
            delete current;
        }
    }
    void insert(type value,iterator position)
    {
        Node*newnode=new Node();
        newnode->data = value;
        if(First == NULL)
        {
            newnode->Next=NULL;
            newnode->Previous=NULL;
            First=newnode;
            Last=newnode;
            size_of_list++;
        }
        else if(position.node_iterator == Last&&position.begin_list==false)
        {
            push_back(value);
        }
        else if(position.node_iterator == First&&position.begin_list==true)
        {
            newnode->Next=position.node_iterator;
            newnode->Previous=NULL;
            position.node_iterator->Previous=newnode;
            First=newnode;
            size_of_list++;
        }
        else
        {
            newnode->Next = position.node_iterator;
            newnode->Previous = position.node_iterator->Previous;
            position.node_iterator->Previous=newnode;
            newnode->Previous->Next=newnode;
            size_of_list++;
        }

    }
    iterator erase(iterator position)
    {
        if(position.node_iterator == First)
        {
            Node*del=position.node_iterator;
            First=position.node_iterator->Next;
            position.node_iterator=position.node_iterator->Next;
            delete del;
        }
        else if(position.node_iterator == Last)
        {
            Last=Last->Previous;
            delete Last->Next;
            Last->Next=NULL;
            iterator(Last);
            throw("This Position is after the last element .");
        }
        else
        {
            Node*del=position.node_iterator;
            position.node_iterator->Previous->Next=position.node_iterator->Next;
            position.node_iterator->Next->Previous=position.node_iterator->Previous;
            position.node_iterator=position.node_iterator->Next;
            delete del;
        }
        size_of_list--;
    }
    list& operator=(list&another_list)
    {
        if(another_list.First != NULL)
        {
            Node*current=another_list.First;
            while(current != NULL)
            {
                this->push_back(current->data);
                current=current->Next;
            }
            return *this;
        }
        return *this;
    }
    void print()
    {
        Node *current = this->First;
        while (current != NULL)
        {
            cout<<current->data<<" ";
            current = current->Next;
        }
    }
};
int main()
{
    list<int> myList;
    try
    {
        myList.push_back(1);
        myList.push_back(2);
        myList.push_back(3);
        list<int>::iterator it = myList.begin();
        it++;
        cout<<"Value of iterator : ";
        cout << *it<<endl;
        cout<<"List : "<<endl;
        myList.print();
        cout<<endl;
        myList.insert(0,myList.begin());
        cout<<"List after insert (0) at First : "<<endl;
        myList.print();
        cout<<endl;
        myList.insert(4,myList.end());
        cout<<"List after insert (4) at end : "<<endl;
        myList.print();
        cout<<endl;
        cout<<"List after insert (2) at Position of Iterator That is 2 : "<<endl;
        myList.insert(2,it);
        myList.print();
        cout<<endl;
        myList.insert(100,myList.begin());
        cout<<"List after insert (100) at First : "<<endl;
        myList.print();
        cout<<endl;
        myList.erase(it);
        cout<<"List after erase position of iterator That is 2 : "<<endl;
        myList.print();
        cout<<endl;
        myList.erase(myList.begin());
        cout<<"List after erase First List That is 100 : "<<endl;
        myList.print();
        cout<<endl;
        myList.erase(myList.end());
    }
    catch(const char*s)
    {
        cout<<"List after erase end List That is 4 : "<<endl;
        myList.print();
        cout<<endl;
        cout<<s<<endl;
    }
}
